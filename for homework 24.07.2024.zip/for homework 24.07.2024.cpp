﻿#include <iostream>

using namespace std;

int main()
{
    const int height = 10;
    int n;

    cout << "1.\n\n";
    for (int i = 1; i <= 10; ++i) {
        for (int j = 1; j <= 10; ++j) {
            cout << i * j << "\t";
        }
        cout << std::endl;
    }

    cout << "\n\n";

    cout << "3.\n\n";
    for (int i = 1; i <= height; ++i) {
        for (int j = 1; j <= 2 * height - 1; ++j) {
            if (j == height - i + 1 || j == height + i - 1 || i == height) {
                cout << '*';
            }
            else {
                cout << ' ';
            }
        }
        cout << endl;
    }

    cout << "\n\n";

    cout << "4.\n\n";
    for (int i = 1; i <= height; ++i) {
        for (int j = 1; j <= 2 * height - 1; ++j) {
            if (j >= height - i + 1 && j <= height + i - 1) {
                cout << '*';
            }
            else {
                cout << ' ';
            }
        }
        cout << endl;
    }

    cout << "\n\n";

    cout << "5.\n\n";

    cout << "Reqemi daxil edin(reqem: 10):\n";
    cin >> n;

    for (int i = 1; i <= n; ++i) {
        for (int j = i; j < n; ++j) {
            cout << " ";
        }

        for (int k = 1; k <= (2 * i - 1); ++k) {
            if (k == 1 || k == (2 * i - 1)) {
                cout << "*";
            }
            else {
                cout << " ";
            }
        }
        cout << endl;
    }

    for (int i = n - 1; i >= 1; --i) {
        for (int j = n; j > i; --j) {
            cout << " ";
        }
        for (int k = 1; k <= (2 * i - 1); ++k) {
            if (k == 1 || k == (2 * i - 1)) {
                cout << "*";
            }
            else {
                cout << " ";
            }
        }
        cout << endl;
    }

    cout << "\n\n";

    cout << "6.\n\n";

    for (int i = 1; i <= height; ++i) {
        for (int j = 1; j <= height - i; ++j) {
            cout << ' ';
        }
        for (int j = 1; j <= 2 * i - 1; ++j) {
            cout << '*';
        }
        cout << endl;
    }

    for (int i = height - 1; i >= 1; --i) {
        for (int j = 1; j <= height - i; ++j) {
            cout << ' ';
        }
        for (int j = 1; j <= 2 * i - 1; ++j) {
            cout << '*';
        }
        cout << endl;
    }



}
